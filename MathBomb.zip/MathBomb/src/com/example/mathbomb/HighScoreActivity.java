package com.example.mathbomb;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class HighScoreActivity extends Activity {

	TextView score, date, highscore, easy, normal, normalscore, normaldate, hard, hardscore, harddate;
	Button okbutton;
	@SuppressLint("SimpleDateFormat")
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_highscore);
		ArrayList<Record> mRecord = null;
        try {
			mRecord = SingleRecord.get(this).getDetails();
			DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm");
			
			Record recordeasy = mRecord.get(StartGameActivity.indexEasy);
        	highscore = (TextView)findViewById(R.id.highscoreshow);
    		
        	easy = (TextView)findViewById(R.id.easy);
        	easy.setText(StartGameActivity.category[0]);
        	        	
            score = (TextView)findViewById(R.id.score);
    		score.setText(recordeasy.getScore().toString());
    		 
    		date = (TextView)findViewById(R.id.date);    		
    		date.setText(dateFormat.format(recordeasy.getDate()) + "");
    		
    		Record recordnormal = mRecord.get(StartGameActivity.indexNormal);
    		
    		normal = (TextView)findViewById(R.id.normal);
    		normal.setText(StartGameActivity.category[1]);
    		
    		normalscore = (TextView)findViewById(R.id.normalscore);
    		normalscore.setText(recordnormal.getScore().toString());
     		 
     		normaldate = (TextView)findViewById(R.id.normaldate);
     		normaldate.setText(dateFormat.format(recordnormal.getDate()) + "");
     		
     		Record recordhard = mRecord.get(StartGameActivity.indexHard);
     		
     		hard = (TextView)findViewById(R.id.hard);
    		hard.setText(StartGameActivity.category[2]);
    		
    		hardscore = (TextView)findViewById(R.id.hardscore);
    		hardscore.setText(recordhard.getScore().toString());
     		 
     		harddate = (TextView)findViewById(R.id.harddate);
     		harddate.setText(dateFormat.format(recordhard.getDate()) + "");     		
     		
    		okbutton = (Button)findViewById(R.id.ok_highscore);
    		okbutton.setOnClickListener(new View.OnClickListener() {
    			public void onClick(View v) {
    				finish();
    			}
    		});
			
		} catch (Exception e) {
			e.printStackTrace(); 
			highscore = (TextView)findViewById(R.id.highscoreshow);
			
	   	     score = (TextView)findViewById(R.id.score);
	   		 score.setText("norecord");
	   		 date = (TextView)findViewById(R.id.date);
	   			date.setText("norecord");
	   			
	   			okbutton = (Button)findViewById(R.id.ok_highscore);
	   			okbutton.setOnClickListener(new View.OnClickListener() {
	   				public void onClick(View v) {
	   					finish();
	   				}
   			});
		}
	}
	
}