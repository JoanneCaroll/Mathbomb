package com.example.mathbomb;

public class HighScore {

}
