package com.example.mathbomb;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ScoreShow extends Activity {

	TextView score, date, highscore;
	Button okbutton;
	@SuppressLint("SimpleDateFormat")
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.highscore_single);
		ArrayList<Record> mRecord = null;
        try {
			mRecord = SingleRecord.get(this).getDetails();
		} catch (Exception e) {
			e.printStackTrace(); 
		}
        Record record = mRecord.get(0);
        
        highscore = (TextView)findViewById(R.id.highscoreshow);
		
        score = (TextView)findViewById(R.id.score);
		score.setText(record.getScore().toString());
		
		date = (TextView)findViewById(R.id.date);
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		date.setText(dateFormat.format(record.getDate()) + "");
		
		okbutton = (Button)findViewById(R.id.ok_highscore);
		okbutton.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				finish();
			}
		});
	}
	
}
