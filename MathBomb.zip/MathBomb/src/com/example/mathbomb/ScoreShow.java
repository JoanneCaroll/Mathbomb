package com.example.mathbomb;

public class ScoreShow {

}
